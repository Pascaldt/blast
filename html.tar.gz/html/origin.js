// Event-dependent variables
		var lat = 41.315308 
		var lng = 1.921585 
		var date = "2014-04-10T11:16:56.385191Z" 
		var loctime = "13:16" 
		var dlat = 9.428433 
		var dlng = 4.922468 
		var isnight= "Jour" 
		var weekday= "Thu" 
		var idev= "gfz2014gztd" 
		var idorg= "Origin#20140410111819.549779.5785" 
